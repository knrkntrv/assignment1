package com.java.skillmanagement.enums;


public interface CodeEnum {
    Integer getCode();

}
