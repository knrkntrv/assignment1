/**
 * 
 */
package com.java.skillmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.java.skillmanagement.dto.ResponseDto;
import com.java.skillmanagement.entity.EmployeeSkillProficiency;
import com.java.skillmanagement.service.EmployeeSkillManageService;



@CrossOrigin
@RestController
public class EmployeeSkillManageController {

	@Autowired
	EmployeeSkillManageService employeeSkillService;
	
	@Autowired
	private ResponseDto responseDto;
	
	/**
	 * API to retrieve all the records
	 * 
	 *  
	 */
	
	@GetMapping("/employee/skill")
    public ResponseEntity<ResponseDto> findAll(@RequestParam(value = "page", defaultValue = "1") Integer page,
                                     @RequestParam(value = "size", defaultValue = "10") Integer size) throws Exception {
		try {
			Page<EmployeeSkillProficiency> returnData= null;
			PageRequest request = PageRequest.of(page - 1, size);
			returnData = employeeSkillService.findAll(request);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Successfully retrived record");
			responseDto.setData((Object) returnData);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode());       
    }
	
	/**
	 * API to retrieve the record by id
	 * 
	 *  
	 */
	
	@GetMapping("/employee/{id}")
    public ResponseEntity<ResponseDto> showOne(@PathVariable("id") int id) throws Exception {
		
		try {
			EmployeeSkillProficiency returnData= null;
			returnData = employeeSkillService.findOne(id);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Successfully retrived record");
			responseDto.setData((Object) returnData);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode());  
	}	
	
	/**
	 * API to retrieve the records by skillname
	 * 
	 *  
	 */
	
	@GetMapping(value = "/employee/skill/{skillname}")
	public ResponseEntity<ResponseDto> getPersoneByName(@PathVariable("skillname") String skill) throws Exception {
		try {
			List<EmployeeSkillProficiency> returnData= null;
			returnData = employeeSkillService.findBySkills(skill);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Successfully retrived record");
			responseDto.setData((Object) returnData);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode()); 
		
	}
	
	/**
	 * API to create the record
	 * 
	 *  
	 */
	
	@PostMapping("/employee/skill")
    public ResponseEntity<ResponseDto> create(@RequestBody EmployeeSkillProficiency inputData) throws Exception {
		
		try {
    		EmployeeSkillProficiency returnData= null;
			returnData = employeeSkillService.save(inputData);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Record created Successfully....");
			responseDto.setData((Object) returnData);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode());
		
    }
	
	/**
	 * API to update the record
	 * 
	 * 
	 */
	
    @PutMapping("/employee/{id}")
    public ResponseEntity<ResponseDto> edit(@PathVariable("id") int scheduleId,
    												@RequestBody EmployeeSkillProficiency inputData) throws Exception{		
    	try {
    		EmployeeSkillProficiency returnData= null;
			returnData = employeeSkillService.update(inputData);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Successfully updated....");
			responseDto.setData((Object) returnData);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode()); 
    	
    }
    
    /**
	 * API to delete the record
	 * 
	 *  
	 */
    
    @DeleteMapping("/employee/{id}" )
    public ResponseEntity<ResponseDto> delete(@PathVariable("id") int id) {
    	
    	try {
    		employeeSkillService.delete(id);
			responseDto.setResponseCode(HttpStatus.OK);
			responseDto.setResponseMessage("Record deleted Successfully ...");
			responseDto.setData((Object) null);
			
		}catch(Exception e) {
			responseDto.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR);
			responseDto.setResponseMessage("Internal Server Error");
			responseDto.setData(null);
		}
		return new ResponseEntity<ResponseDto>(responseDto, responseDto.getResponseCode()); 
    	
    }
}
