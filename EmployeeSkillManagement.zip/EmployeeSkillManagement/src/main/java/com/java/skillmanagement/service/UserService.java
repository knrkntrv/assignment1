package com.java.skillmanagement.service;


import java.util.Collection;

import com.java.skillmanagement.entity.User;


public interface UserService {
    User findOne(String email);

    Collection<User> findByRole(String role);

    User save(User user);

    User update(User user);
}
